<?php
include 'classes/config.php';

if ($_POST['district_id']) {
	$query = "SELECT * FROM upazila_tb where dis_id=".$_POST['district_id'];
	$result = $db->query($query);
	if ($result->num_rows > 0 ) {
			echo '<option value="">Select Upazila</option>';
		 while ($row = $result->fetch_assoc()) {
		 	echo '<option value='.$row['upa_id'].'>'.$row['upazila_name'].'</option>';
		 }
	}else{

		echo '<option>No Upazila Found!</option>';
	}

	}elseif ($_POST['upazila_id']) {
	 
	$query = "SELECT * FROM union_tb where upa_id=".$_POST['upazila_id'];
	$result = $db->query($query);
	if ($result->num_rows > 0 ) {
			echo '<option value="">Select Union</option>';
		 while ($row = $result->fetch_assoc()) {
		 	echo '<option value='.$row['uni_id'].'>'.$row['union_name'].'</option>';
		 }
	}else{

		echo '<option>No Union Found!</option>';
	}

}


?>