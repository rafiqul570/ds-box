function GetUpazila(id){
    $('#upazila').html('');
    $('#union').html('<option>Select Union</option>');
    $.ajax({
      type:'post',
      url: 'ajaxdata.php',
      data : { district_id : id},
      success : function(data){
         $('#upazila').html(data);
      }

    })
  }

  function GetUnion(id){ 
    $('#union').html('');
    $.ajax({
      type:'post',
      url: 'ajaxdata.php',
      data : { upazila_id : id},
      success : function(data){
         $('#union').html(data);
      }

    })
  }

