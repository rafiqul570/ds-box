<?php
spl_autoload_register(function($class_name){
include "classes/".$class_name.".php";
}); 
//error_reporting(0);  

/*
class
*/

class Dsbox{
  
  private $db;

  public function __construct(){
    $this->db = new Database();
  }

  //===================Insert District===================//

   public function insertDistrict($data){
            $district_name  = $data['district_name'];
            
       if ($district_name == "" ) {
            
      $msg = '<div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
               <strong>Error !</strong> Field must not be Empty !
              </div>';
      
           return $msg; 
       
     }


    $query = "INSERT INTO district_tb(district_name)VALUES('$district_name');";
    $result = $this->db->insert($query);

    if ($result) {

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Success !</strong> Data Inserte Successfully.
            </div>';
  
       return $msg;
     
       
   }else{

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Error !</strong> Data Not Inserted.
            </div>';
  
       return $msg; 
       } 
   }
 //===================SELECT District===================//
   public function getAllDistrictData(){
        $query = "SELECT * FROM district_tb ORDER BY dis_id DESC";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }
 //===================SELECT UPAZILA===================//
    public function getAllUpazilaData(){
        $query = "SELECT * FROM upazila_tb ORDER BY upa_id DESC";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }


  //===================Insert Upazila===================//

   public function insertUpazila($data){
            $upazila_name = $data['upazila_name'];
            $district = $data['district'];
            
       if ($upazila_name == "") {
            
      $msg = '<div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
               <strong>Error !</strong> Field must not be Empty !
              </div>';
      
           return $msg; 
       
     }


    $query = "INSERT INTO upazila_tb(upazila_name,district)VALUES('$upazila_name','$district');";
    $result = $this->db->insert($query);

    if ($result) {

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Success !</strong> Data Inserte Successfully.
            </div>';
  
       return $msg;
     
       
   }else{

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Error !</strong> Data Not Inserted.
            </div>';
  
       return $msg; 
       } 
   }


   //===================Insert UNION ===================//

   public function insertUnion($data){
            $union_name = $data['union_name'];
            $upazila = $data['upazila'];
            
       if ($union_name == "") {
            
      $msg = '<div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
               <strong>Error !</strong> Field must not be Empty !
              </div>';
      
           return $msg; 
       
     }


    $query = "INSERT INTO union_tb(union_name,upazila)VALUES('$union_name','$upazila');";
    $result = $this->db->insert($query);

    if ($result) {

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Success !</strong> Data Inserte Successfully.
            </div>';
  
       return $msg;
     
       
   }else{

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Error !</strong> Data Not Inserted.
            </div>';
  
       return $msg; 
       } 
   }


   //===================SELECT UNION===================//
    public function getAllUnionData(){
        $query = "SELECT * FROM union_tb ORDER BY uni_id DESC";
        $result = $this->db->select($query);
         if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }



}