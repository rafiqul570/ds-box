<?php
  include 'classes/config.php';
  $query = "SELECT * FROM district_tb Order by district_name";
  $result = $db->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Dynamic Dependent Select Box using jQuery, Ajax and PHP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <script src="jquery.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <div class="row">
    <div class="col-md-4 col-md-offset-4">
    <form>
        <div class="form-group">
          <label for="email">District</label>
          <select name="district" id="district" class="form-control" onchange="GetUpazila(this.value)"  required>
            <option label="Choose One"></option>
          <?php
            if ($result->num_rows > 0 ) {
               while ($row = $result->fetch_assoc()) {
                echo '<option value='.$row['dis_id'].'>'.$row['district_name'].'</option>';
               }
            }
          ?> 
          </select>
        </div>
        <div class="form-group">
          <label for="pwd">Upazila</label>
          <select name="upazila" id="upazila" class="form-control" onchange="GetUnion(this.value)"  required>
            <option label="Choose One"></option>
          </select>
        </div>

        <div class="form-group">
          <label for="pwd">Union</label>
          <select name="union" id="union" class="form-control">
            <option label="Choose One"></option>
          </select>
        </div>
      </form>
    </div>
  </div>
</div>
<script src="js/main.js"></script>

<!-- <script>
  function GetUpazila(id){
    $('#upazila').html('');
    $('#union').html('<option>Select Union</option>');
    $.ajax({
      type:'post',
      url: 'ajaxdata.php',
      data : { district_id : id},
      success : function(data){
         $('#upazila').html(data);
      }

    })
  }

  function GetUnion(id){ 
    $('#union').html('');
    $.ajax({
      type:'post',
      url: 'ajaxdata.php',
      data : { upazila_id : id},
      success : function(data){
         $('#union').html(data);
      }

    })
  }

</script> -->
</body>
</html>
