-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2023 at 03:33 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ds_box`
--

-- --------------------------------------------------------

--
-- Table structure for table `district_tb`
--

CREATE TABLE `district_tb` (
  `dis_id` int(11) NOT NULL,
  `district_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `district_tb`
--

INSERT INTO `district_tb` (`dis_id`, `district_name`) VALUES
(1, 'Bagerhat'),
(2, 'Pirojpur'),
(3, 'Gopalgong');

-- --------------------------------------------------------

--
-- Table structure for table `union_tb`
--

CREATE TABLE `union_tb` (
  `uni_id` int(11) NOT NULL,
  `upa_id` int(11) NOT NULL,
  `union_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `union_tb`
--

INSERT INTO `union_tb` (`uni_id`, `upa_id`, `union_name`) VALUES
(1, 1, 'Kachua'),
(2, 1, 'Badal');

-- --------------------------------------------------------

--
-- Table structure for table `upazila_tb`
--

CREATE TABLE `upazila_tb` (
  `upa_id` int(11) NOT NULL,
  `dis_id` int(11) NOT NULL,
  `upazila_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upazila_tb`
--

INSERT INTO `upazila_tb` (`upa_id`, `dis_id`, `upazila_name`) VALUES
(1, 1, 'Kachua'),
(2, 1, 'Chitalmary'),
(3, 2, 'Najirpur'),
(4, 3, 'Gournody');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `district_tb`
--
ALTER TABLE `district_tb`
  ADD PRIMARY KEY (`dis_id`);

--
-- Indexes for table `union_tb`
--
ALTER TABLE `union_tb`
  ADD PRIMARY KEY (`uni_id`);

--
-- Indexes for table `upazila_tb`
--
ALTER TABLE `upazila_tb`
  ADD PRIMARY KEY (`upa_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `district_tb`
--
ALTER TABLE `district_tb`
  MODIFY `dis_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `union_tb`
--
ALTER TABLE `union_tb`
  MODIFY `uni_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `upazila_tb`
--
ALTER TABLE `upazila_tb`
  MODIFY `upa_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
